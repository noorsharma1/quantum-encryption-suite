import React from 'react';

export default function ScannerPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Encryption Scanner</h1>
      <p>File upload, rule selection, and scan initiation will appear here.</p>
    </div>
  );
}
