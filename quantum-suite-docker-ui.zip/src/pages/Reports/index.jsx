import React from 'react';

export default function ReportsPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Compliance Reports</h1>
      <p>Download scan reports in PDF or Excel formats.</p>
    </div>
  );
}
