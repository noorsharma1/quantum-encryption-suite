import React from 'react';

export default function ReportsPage() {
  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">📊 Compliance Reports</h1>
      <p>View and download scan reports in PDF or Excel format.</p>
      {/* Report list and download buttons (to be wired) */}
    </div>
  );
}
