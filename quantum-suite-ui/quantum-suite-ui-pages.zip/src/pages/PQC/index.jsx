import React from 'react';

export default function PQCPage() {
  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">🛡 Post-Quantum Key Generator</h1>
      <p>Generate Kyber or Dilithium keypairs securely.</p>
      {/* Dropdown, generate button, key display (to be wired) */}
    </div>
  );
}
