import React from 'react';

export default function ScannerPage() {
  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">🔍 Encryption Scanner</h1>
      <p>Select a directory or file, choose scan rules, and launch scan.</p>
      {/* File input, rule selector, scan button (to be wired) */}
    </div>
  );
}
